/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project3;

/**
 *
 * @author miran
 */
public class HashTable<T> {

    int M;
    Node<String>[] table;

    public HashTable(int M) {
        table = new Node[M];
        this.M = M;

    }

    public boolean insert(Node t) {
        for(int i = 0;i< table.length;i++){
            if(this.table[i] == null){
                this.table[i] = t;
                return true;               
            }
        }
        System.out.println("No enougth space");
        return false;
    }   
    

    public boolean contains(String t) {
        for(int i = 0;i < this.table.length;i++){
            if(table[i].data.trim().equals((String)t)){
                return true;
            }
        }
        return false;
    }
    
    public Node nodefinder(String a){
        for(int i = 0;i < this.table.length;i++){
            String b = (String)table[i].data;
            if(b.trim().equals(a.trim())){
                return table[i];
            }
        }       
        return null;
    }
    

    @Override
    public String toString() {
        String s = "";
        for (int i = 0;i < this.table.length;i++) {
            s += table[i].toString() + "\n";
        }
        return s;
    }
    
    

}
