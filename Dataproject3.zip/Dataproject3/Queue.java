/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project3;


public class Queue<T> {

    public int size; 
    public Node<T> first;
    public Node<T> last; 

    public Queue() {
        size = 0;
        first = null;
        last = null;
    }
    
   
    public int size(){
        return size;
    }
    
    public boolean isEmpty() {
        return first == null;
    }

    public void enqueue(Node item) { 
        Node newNode = item;
        if (isEmpty()) {
            first = newNode;
        } else {
            last.next = newNode;
        }
        last = newNode;
        size++;
    }
    
    public Node dequeue() { 
    if (isEmpty()) {
        System.out.println("Queue is empty. Cannot dequeue.");
        return null;
    }

    Node temp = first; 
    first = first.next; 
    if (first == null) { 
        last = null;
    }
    size--; 
    return temp; 
}
    
    public boolean contains(Node a){
        Node tmp = this.first;
        if(tmp == null){
            return false;
        }else{
            while(tmp != null){
             if(tmp.data.trim().equals((String)a.data.trim())){
                return true;
            }
            tmp = tmp.next;
            }
            
        }
        return false;
    }
    
        @Override
    public String toString() {
        String s = "";
        Node<T> tmp = first;
        while (tmp != null) {
            s += tmp.data.trim() + "->";
            tmp = tmp.next;
        }
        s += "Null";
        return s;
    }

}

