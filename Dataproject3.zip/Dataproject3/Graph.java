package project3;

public class Graph {

    public HashTable<String> mainhash;
    public int vertexnums;

    Graph(int vertexnums) {
        this.mainhash = new HashTable(vertexnums);
    }

    public void addvertex(String a) {
        String[] firstep = a.split(" -> ");
        this.mainhash.insert(new Node(firstep[0]));
    }

    public void ReadGraphFromFile(String a, int index) {
        String[] nametonode = a.split("->");
        String[] contacts = nametonode[1].split(", ");
        for (int i = 0; i < contacts.length; i++) {
            String[] finaltxt = contacts[i].split(": ");
            this.mainhash.table[index].edges.insertLast(new Node(new Edges(nametonode[0], finaltxt[0], finaltxt[1])));
        }
    }

    public String Neighbors(String v1) {
        String s = this.mainhash.nodefinder(v1).edges.toString();
        return s;
    }

    public boolean AreTheyAdjacent(String v1, String v2) {
        Node a1 = this.mainhash.nodefinder(v1);
        if (a1 == null) {
            return false;
        } else {
            Node<Edges> tmp = a1.edges.first;
            while (tmp != null) {
                if (tmp.data.trim().equals((String) v2)) {
                    return true;
                }
                tmp = tmp.next;
            }
            return false;
        }

    }

    public boolean IsThereAPath(String v1, String v2) {
        if (!this.mainhash.contains((String) v1)) {
            return false;
        }
        Node a1 = this.mainhash.nodefinder(v1);
        Node<Edges> tmp = null;
        if (a1.data.trim().equals((String) v2)) {
            return true;
        }
        if (a1.edges.first != null) {
            tmp = a1.edges.first;
        } else {
            return false;
        }

        if (tmp.data.trim().equals((String) v2)) {
            return true;
        }
        while (tmp != null) {
            tmp = tmp.next;
            if (tmp != null) {
                return this.IsThereAPath((String) tmp.data.trim(), v2);
            }

        }
        return false;
    }

    public void NumberOfVerticesInComponent(String v1) {
        int counter = 0;
        for (int i = 0; i < this.mainhash.table.length; i++) {
            if (this.mainhash.table[i].edges.contains(v1)) {
                counter++;
            }
        }
        System.out.println(counter);
    }

    public boolean IsDirected() {
        boolean finisher = false;
        for (int i = 0; i < this.mainhash.table.length; i++) {
            Node a = this.mainhash.table[i];
            if (a.edges.first == null) { //örnek b2 node u
                return true;
            } else {
                Node tmp = this.mainhash.nodefinder((String) a.edges.first.data);
                while (tmp != null) {
                    if (tmp.edges.first == null) {
                        return true;
                    } else {
                        Node tmp2 = this.mainhash.nodefinder((String) tmp.edges.first.data);
                        while (tmp2 != null) {
                            if (tmp2.data.equals((String) a.data)) {
                                finisher = true;
                            }
                            tmp2 = tmp2.next;
                        }
                        if (!finisher) {
                            return true;
                        }
                    }
                    tmp = tmp.next;
                }
            }
        }
        return finisher;
    }

    public void HighestDegree() {
        String max = "";
        int max1 = 0;
        for (int i = 0; i < this.mainhash.table.length; i++) {
            int counter = 0;
            if (this.mainhash.table[i].edges.first == null) {
                continue;
            } else {
                Node curr = this.mainhash.table[i].edges.first;
                while (curr != null) {
                    counter++;
                    curr = curr.next;
                }
                if (max1 <= counter) {
                    max1 = counter;
                    max += this.mainhash.table[i].data;
                }
            }
        }
        System.out.println(max);
    }

    private int getNodeIndex(Node node) {
        for (int i = 0; i < this.mainhash.table.length; i++) {
            if (this.mainhash.table[i] == node) {
                return i;
            }
        }
        return -1;
    }

    public int WhatIsShortestPathLength(String v1, String v2) {
        Node start = this.mainhash.nodefinder(v1);
        if (start == null) {
            return -1;
        }
        Node end = this.mainhash.nodefinder(v2);
        if (end == null) {
            return -1;
        }

        boolean[] visited = new boolean[this.mainhash.M];
        Queue<Node> queue = new Queue<>();
        int[] distances = new int[this.mainhash.M];

        queue.enqueue(start);
        visited[getNodeIndex(start)] = true;
        distances[getNodeIndex(start)] = 0;

        while (!queue.isEmpty()) {
            Node current = queue.dequeue();
            int currentIndex = getNodeIndex(current);

            if (current.data.equals(v2)) {
                return distances[currentIndex];
            }

            Node<Edges> edge = current.edges.first;
            while (edge != null) {
                Node nextNode = this.mainhash.nodefinder(edge.data);
                if (nextNode != null && !visited[getNodeIndex(nextNode)]) {
                    queue.enqueue(nextNode);
                    visited[getNodeIndex(nextNode)] = true;
                    distances[getNodeIndex(nextNode)] = distances[currentIndex] + 1;
                }
                edge = edge.next;
            }
        }

        System.out.println(v1 + " --x-- " + v2);
        return -1;
    }

    public void DFSfromTo(String startVertex, String endVertex) {
        Node start = this.mainhash.nodefinder(startVertex);
        Node end = this.mainhash.nodefinder(endVertex);

        if (start == null || end == null) {
            System.out.println("Error: One or both vertices do not exist.");
            return;
        }

        boolean[] visited = new boolean[this.mainhash.table.length];

        LinkedList<String> path = new LinkedList<>();
        LinkedList<String> weights = new LinkedList<>();
        dfs(start, end, visited, path, weights);
    }

    private void dfs(Node current, Node target, boolean[] visited, LinkedList<String> path, LinkedList<String> weights) {
        int index = getNodeIndex(current);
        visited[index] = true;

        path.insertLast(new Node(current.data));

        if (current.data.equals(target.data)) {
            System.out.println("Path: " + path.toString());
            System.out.println("weights: " + weights.toString());
        } else {
            Node<Edges> edge = current.edges.first;
            while (edge != null) {
                Node neighbor = this.mainhash.nodefinder(edge.data);
                if (neighbor != null) {
                    neighbor.weight = edge.weight;
                }

                if (neighbor != null && !visited[getNodeIndex(neighbor)]) {
                    weights.insertLast(new Node(neighbor.weight));
                    dfs(neighbor, target, visited, path, weights);
                }
                edge = edge.next;
            }
        }

        if (!path.isEmpty()) {
            path.removeLast();
        }
    }

    public void BFSfromTo(String v1, String v2) {// CONTINUE
        Queue<Node> b1 = new Queue();
        Queue<String> b2 = new Queue();
        int i = 0;
        boolean fnsh = true;
        while (fnsh) {
            Node curr = this.mainhash.table[i];
            if (!b1.contains(curr)) {
                b1.enqueue(new Node(curr.data));

            }
            if (curr.data.trim().equals((String) v2)) {
                fnsh = false;
            } else {
                Node tmp = curr.edges.first;
                while (tmp != null) {
                    if (!b1.contains(tmp)) {
                        b1.enqueue(new Node(tmp.data));
                        b2.enqueue(new Node(tmp.weight));
                    }
                    if (tmp.data.trim().equals((String) v2)) {
                        fnsh = false;
                        tmp = null;
                    } else {
                        tmp = tmp.next;
                    }

                }
            }
            i++;
        }
        Node tmp = b1.first;
        Node tmp2 = b2.first;
        while (tmp != null && tmp2 != null) {
            System.out.print(tmp.data + "(" + tmp2.data + ")" + "->");
            tmp = tmp.next;
            tmp2 = tmp2.next;
        }
    }

    private int countPathsDFS(Node current, Node target, boolean[] visited) {
        int index = getNodeIndex(current);

        if (visited[index]) {
            return 0;
        }
        if (current.data.equals(target.data)) {
            return 1;
        }

        visited[index] = true;

        int pathCount = 0;

        Node<Edges> edge = current.edges.first;
        while (edge != null) {            
            Node neighbor = this.mainhash.nodefinder(edge.data);
            if (neighbor != null) {
                pathCount += countPathsDFS(neighbor, target, visited);
            }
            edge = edge.next; 
        }

       

        return pathCount;
    }

    public int NumberOfSimplePaths(String v1, String v2) {
        Node start = this.mainhash.nodefinder(v1);
        Node end = this.mainhash.nodefinder(v2);

        if (start == null || end == null) {
            System.out.println("Error: One or both vertices do not exist.");
            return 0;
        }

        boolean[] visited = new boolean[this.mainhash.table.length];
        return countPathsDFS(start, end, visited);
    }
    
    public boolean IsThereACycle(String v1){
        return this.IsThereAPath(v1, v1);
    }

    public String printgraph() {
        return mainhash.toString();
    }

}
