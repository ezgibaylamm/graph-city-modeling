/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project3;

/**
 *
 * @author miran
 */
public class LinkedList<Edges> {

    public Node first;
    public Node last;
    public int size = 0;

    public void insertFirst(Node x) {
        Node newNode = x;
        newNode.next = first;
        if (last == null) { 
            last = newNode;
        }       
        first = newNode;
        size++;
    }
    
    public void insertLast(Node x) {
        Node<Edges> newNode = x;
        if (last == null) { 
            first = newNode;
            last = newNode;
        } else {
            last.next = newNode;
            last = newNode;
        }
        size++;
    }
    
    public boolean contains(String v1){
        Node<Edges> tmp = this.first;
        while(tmp != null){
            if(tmp.data.trim().equals((String)v1)){
                return true;
            }
            tmp = tmp.next;
        }
        return false;
    }
    
    
    public Node search(String x) {
        Node tmp = first;
        while (tmp != null) {
            if (tmp.data == x) {
                return tmp;
            }
            tmp = tmp.next;
        }
        return null;
    }

  
    public Node[] returnarray(){
        Node[] a1 = new Node[size];
        Node tmp = this.first;
        for(int i = 0;i<this.size;i++){
            a1[i] = tmp;
            tmp = tmp.next;
        }
        return a1;
    } 
    
    public void removeLast() {
    if (this.first == null) return;
    if (this.first == this.last) { 
        this.first = null;
        this.last = null;
        size--;
        return;
    }
    

    Node current = this.first;
    while (current.next != this.last) {
        current = current.next;
    }
    current.next = null; 
    this.last = current; 
    size--;
}
    public boolean isEmpty() {
    return this.first == null;
}


    @Override
    public String toString() {
        String s = "";       
        Node<Edges> tmp = first;
        while (tmp != null) {
            if(tmp.weight != null){
                s += (String)tmp.data + "(" + (String)tmp.weight + "), ";
            tmp = tmp.next;
            } else{
                s += (String)tmp.data + "->";
            tmp = tmp.next;
            }
            
        }
        return s;
    }

}

