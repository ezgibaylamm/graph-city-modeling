
package project3;


public class Stack<T> {

    
    private int N; 
    public Node top; 

    public Stack() {
        this.N = 0;
        this.top = null;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public int size() {
        return N;
    }

    public void push(Node t) {
        if (t == null) {
            return; 
        }

        t.next = top;
        top = t;
        N++;
    }

    public Node pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
            return null;
        }

        Node temp = top; 
        top = top.next; 
        N--;
        return temp;
    }

    public Node top() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot retrieve top.");
            return null;
        }

        return top;
    }

    public boolean contains(Node a) {
        Node temp = top;
        while (temp != null) {
            if (temp.data.trim().equals(a.data.trim())) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }
    
        @Override
    public String toString() {
        String s = "";
        Node tmp = top;
        while (tmp != null) {
            s += tmp.data.trim() + "->";
            tmp = tmp.next;
        }
        s += "Null";
        return s;
    }

}

