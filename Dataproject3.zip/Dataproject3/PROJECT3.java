package project3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PROJECT3 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Graph maingraph;
        int counter = 0;
        LinkedList<String> cities = new LinkedList<>();

        try {// Counting lines
            File file = new File("graph (1).txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String text = scanner.nextLine();
                counter++;
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Dosya bulunamadı.");
            e.printStackTrace();
        }

        maingraph = new Graph(counter);

        try {// Defining vertexes
            File file = new File("graph (1).txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String text = scanner.nextLine();
                maingraph.addvertex(text);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Dosya bulunamadı.");
            e.printStackTrace();
        }
        int a = 0;
        try {// Defining edges
            File file = new File("graph (1).txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String text = scanner.nextLine();
                maingraph.ReadGraphFromFile(text, a);
                a++;
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Dosya bulunamadı.");
            e.printStackTrace();
        }

        System.out.println("1- Load graph data");
        System.out.println("2- Search for path");
        System.out.println("3- BFS");
        System.out.println("4- DFS");
        System.out.println("5- Shortest path length between 2 vertices");
        System.out.println("6- Numbers of simple path between 2 vertices");
        System.out.println("7- Neighbors of a vertex");
        System.out.println("8- Highest degree");
        System.out.println("9- Check that graph is directed or undirected");
        System.out.println("10- Check for 2 vertices if they are adjacent ");
        System.out.println("11- Check for path if cylce or not");
        System.out.println("12- prints the number of vertices that exist in the component" );
        int input2 = input.nextInt();
        switch (input2) {
            case 1:
                System.out.println(maingraph.mainhash.toString());
                break;
            case 2:
                System.out.println("Enter first vertex");
                String a1 = input.next();
                System.out.println("Enter second vertex");
                String a2 = input.next();
                System.out.println(maingraph.IsThereAPath(a1, a2));
                break;
            case 3:
                System.out.println("Enter first vertex");
                String a3 = input.next();
                System.out.println("Enter second vertex");
                String a4 = input.next();
                maingraph.BFSfromTo(a3, a4);
                break;
            case 4:
                System.out.println("Enter first vertex");
                String a5 = input.next();
                System.out.println("Enter second vertex");
                String a6 = input.next();
                maingraph.DFSfromTo(a5, a6);
                
                break;
            case 5:
                System.out.println("Enter first vertex");
                String a7 = input.next();
                System.out.println("Enter second vertex");
                String a8 = input.next();
                System.out.println(maingraph.WhatIsShortestPathLength(a7, a8));
                break;
            case 6:
                System.out.println("Enter first vertex");
                String a9 = input.next();
                System.out.println("Enter second vertex");
                String a10 = input.next();
                System.out.println(maingraph.NumberOfSimplePaths(a9, a10));
                break;
            case 7:
                System.out.println("Enter vertex");
                String a11 = input.next();
                System.out.println(maingraph.Neighbors(a11));
                break;
            case 8:
                maingraph.HighestDegree();
                break;
            case 9:
                System.out.println(maingraph.IsDirected());
                break;
            case 10:
                System.out.println("Enter first vertex");
                String a12 = input.next();
                System.out.println("Enter second vertex");
                String a13 = input.next();
                System.out.println(maingraph.AreTheyAdjacent(a12, a13));
                break;
            case 11:
                System.out.println("Enter a vertex");
                String a14 = input.next();
                System.out.println(maingraph.IsThereACycle(a14));
                break;
            case 12:
                System.out.println("Enter a vertex");
                String a15 = input.next();
                maingraph.NumberOfVerticesInComponent(a15);
                break;
            default:
                System.out.println("Invalid input");
                break;

        }

    }// END OF MAIN

}
