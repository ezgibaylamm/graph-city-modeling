/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project3;

/**
 *
 * @author miran
 */
public class Node<T> {
    public String data;
    public Node next;
    public String weight;
    public boolean visited = false;
    public LinkedList<Edges> edges;

    Node(String data) {
        this.data = data.trim();
        this.next = null;
        this.edges = new LinkedList<Edges>();
    }
    
    Node(Edges e1){
        this.data =  e1.to.trim();
        this.weight = e1.weight;
    }
    
    
    public void addnode(Node a){
        this.edges.insertLast(a);
    }
    

    @Override
    public String toString() {
        String s = "";
        s += this.data + ": ";
        s += this.edges.toString();
        return s; 
    }

    
    
    
    
    
}

