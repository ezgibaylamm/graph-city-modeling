package project3;


public class Edges {
    String from;
    String to;
    String weight;
    Edges(String from,String to,String weight){
        this.from = from;
        this.to = to;
        this.weight = weight;
    }  
}
